package com.wpp.ncoa.service;

import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import com.wpp.ncoa.pojo.Address;
import com.wpp.ncoa.service.helper.AddrInParser;
import com.wpp.ncoa.service.helper.CSVAddrWriter;
import com.wpp.ncoa.service.helper.GuideFileParser;
import com.wpp.ncoa.util.SHAUtils;


public class NCOAService {
	
	private SparkSession spark;
	
	public NCOAService() {
		spark = SparkSession.builder().master("local").getOrCreate();
	}

	public void processNCOA(String input_file, String hased_guide_file, String new_addr_guide_file, String output_file) {
		Dataset<Address> addrDataset = new AddrInParser(input_file, spark).getAddrDataset();
		GuideFileParser.createGuideFileDataset(hased_guide_file, new_addr_guide_file, spark);
		CSVAddrWriter.writeHeader(output_file, "OLD ADDRESS","NEW ADDRESS","RETURN CODE");
		addrDataset.foreach(address -> processRecord(address,output_file));
	}
	
	private static void processRecord(Address address, String output_file) {
		String outAdd = " ",return_code;
		Column addrCol = new Column("hashedAddress");
		System.out.println("Address : "+address);
		System.out.println("processRule1(address) : "+processRule1(address));
		Dataset<Row> guideFileDataset = GuideFileParser.getGuideFileDataset();
		System.out.println("guideFileDataset 1 : "+guideFileDataset);
		guideFileDataset.show();
		System.out.println("guideFileDataset 2 : "+guideFileDataset);
		Dataset<Row> newAddr = guideFileDataset.select("address").where(addrCol.equalTo(processRule1(address))); 
		if(newAddr != null) {
			outAdd = newAddr.first().getString(0);
			return_code = "A";
		}else if ((newAddr =  guideFileDataset.select("address").where(addrCol.equalTo(processRule2(address)))) != null )  {
			outAdd = newAddr.first().getString(0);
			return_code = "01";
		}else {
			return_code = "X";
		}
		CSVAddrWriter.write(output_file,address.toString(), outAdd, return_code);
	}

	public static String processRule1(Address address) {
		return SHAUtils.getHashedValue(address.getFirstName() +" "+ address.getLastName()+" "+ address.getAddLine1()+" "+ address.getStateCode()+" "+ address.getZipCode());
	}
	
	public static String processRule2(Address address) {
		return SHAUtils.getHashedValue(address.getLastName() +" "+ address.getFirstName()+" "+ address.getAddLine1()+" "+ address.getStateCode()+" "+ address.getZipCode());
	}

}
