package com.wpp.ncoa.service.helper;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;

import com.wpp.ncoa.pojo.Address;

public class AddrInParser {
	

	private Dataset<Address> addrDatset;
	private String inpFile;
	SparkSession spark;
	
	public AddrInParser(String inpFile, SparkSession session) {
		this.inpFile = NCOAConstants.PATH+inpFile;
		this.spark = session;
	}
	

	public Dataset<Address> getAddrDataset() {
		if(addrDatset == null) {
			loadAddress();
		}
		return addrDatset;
	}

	private void loadAddress() {
		addrDatset = spark.read().option("header", false).csv(inpFile).as(Encoders.STRING()).map(a -> parseAddresLine(a),Encoders.bean(Address.class));
	}
	
	private static Address parseAddresLine(String str) {
		String[] split = str.split(" ");
		Address addr = new Address();
		addr.setFirstName(split[0].trim());
		addr.setLastName(split[1].trim());
		addr.setStateCode(split[split.length-2].trim());
		addr.setZipCode(split[split.length-1].trim());
		StringBuilder sb = new StringBuilder();
		for (int i = 2; i < split.length-2; i++) {
			sb.append(split[i]).append(" ");
		}
		addr.setAddLine1(sb.toString().trim());
		return addr;
	}
	
}