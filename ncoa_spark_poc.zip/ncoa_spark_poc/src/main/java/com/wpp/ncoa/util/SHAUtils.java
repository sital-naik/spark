package com.wpp.ncoa.util;

import java.math.BigInteger;
import java.security.MessageDigest;


public class SHAUtils {
	
	private static final String SHA_ALOGO = "SHA-256";
	
	private static MessageDigest md;
	
	private static MessageDigest getMDInstance() {
		if(md == null) {
			try {
				md = MessageDigest.getInstance(SHA_ALOGO);
			} catch (Exception e) {
				e.printStackTrace();
			} 
		}
		return md;
	}
	
	public static String getHashedValue(String input){
        byte[] messageDigest = getMDInstance().digest(input.getBytes()); 
        BigInteger no = new BigInteger(1, messageDigest); 
        String hashtext = no.toString(16); 
        while (hashtext.length() < 64) { 
            hashtext = "0" + hashtext; 
        } 
        return hashtext;
	}
	
}
