package com.wpp.ncoa.service.helper;


import java.io.Serializable;

import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class GuideFileParser implements Serializable{

	private static final long serialVersionUID = 1L;
	private static Dataset<Row> guideFileDataset;
	
	public static void createGuideFileDataset(String hased_guide_file, String new_addr_guide_file, SparkSession spark) {
		if (guideFileDataset == null) {
			loadGuideFiles(NCOAConstants.PATH+hased_guide_file, NCOAConstants.PATH+new_addr_guide_file, spark);
		}
	}
	

	public static Dataset<Row> getGuideFileDataset() {
		return guideFileDataset;
	}

	private static void loadGuideFiles(String hased_guide_file, String new_addr_guide_file, SparkSession spark) {
		Dataset<Row> hashedDataset = spark.read().option("header", false).csv(hased_guide_file);
		Dataset<Row> addrDataset = spark.read().option("header", false).csv(new_addr_guide_file);
		guideFileDataset = hashedDataset
				.join(addrDataset, hashedDataset.col("_C0").equalTo(addrDataset.col("_C0")), "inner")
				.select(hashedDataset.col("_C1").as("hashedAddress"), addrDataset.col("_C1").as("address"),
						addrDataset.col("_C2").as("months"));
		System.out.println("before showing getGuideFileDataset : "+guideFileDataset);
		guideFileDataset.show();
		Dataset<Row> where = guideFileDataset.select("address").where(new Column("hashedAddress").equalTo("afc830b4690fa9bdc61ce64ed527767d9ee5eacef35577d68c9347d04d598091"));
		where.show();
		System.out.println("after showing getGuideFileDataset : "+guideFileDataset);

	}

}
