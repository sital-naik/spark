package com.wpp.ncoa.service.helper;

public class NCOAConstants {
	
	public static final String PATH = "src/main/resources/";

}
