package com.wpp.ncoa;


import com.wpp.ncoa.service.NCOAService;

public class App {
	public static void main(String[] args) {
		NCOAService ns = new NCOAService();

		String input_file = "S1.Input File.csv";
		String hased_guide_file = "S1.Encrypted 10 Guide File.csv";
		String new_addr_guide_file = "S1.COA Guide File.csv";
		String output_file = "S1.COA Output.csv";
		
		ns.processNCOA(input_file, hased_guide_file, new_addr_guide_file, output_file);

		System.out.println("NCOA Process Completed");
	}
}
