package com.wpp.ncoa.service.helper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class CSVAddrWriter {
	
	public static void writeHeader(String fileName, String... headers) {
		Path filePath = Paths.get(NCOAConstants.PATH+fileName);
		StringBuilder sb = new StringBuilder();
		int length = headers.length;
		for (int i = 0; i < length-1; i++) {
			sb.append(headers[i]).append(",");
		}
		sb.append(headers[length-1]).append("\n");
		try {
			Files.write(filePath, sb.toString().getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void write(String fileName,String oldAdd, String new_add, String retun_code) {
		String line = oldAdd+", "+new_add+", "+retun_code+"\n";
		try {
			Files.write(Paths.get(NCOAConstants.PATH+fileName), line.getBytes(),StandardOpenOption.APPEND);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*private Path path;
	private String line;
	
	public CSVAddrWriter(String filename) {
		path = Paths.get("src/main/resources/"+filename);
		line = "OLD ADDRESS, NEW ADDRESS, RETURN CODE \n";
		try {
			Files.write(path, line.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void write(String oldAdd, String new_add, String retun_code) {
		line = oldAdd+", "+new_add+", "+retun_code+"\n";
		try {
			Files.write(path, line.getBytes(),StandardOpenOption.APPEND);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}*/

}
