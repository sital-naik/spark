package com.wpp.ncoa.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.mapper.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;

import com.wpp.ncoa.entity.Address;
import com.wpp.ncoa.entity.OutputEntity;

@Repository
public class ELasticSearchDAO {
	
	private RestHighLevelClient client;
	private ObjectMapper objectMapper;

	@Autowired
	public ELasticSearchDAO(RestHighLevelClient client, ObjectMapper objectMapper) {
		this.client = client;
		this.objectMapper = objectMapper;
	}

	@Async
	public CompletableFuture<List<OutputEntity>> searchCOA(List<Address> list) throws InterruptedException {
		List<OutputEntity> result = new LinkedList<>();
		
        return CompletableFuture.completedFuture(result);
	}
	
	

}
