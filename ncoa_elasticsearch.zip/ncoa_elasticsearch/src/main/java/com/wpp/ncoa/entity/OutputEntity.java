package com.wpp.ncoa.entity;

public class OutputEntity {

	private Address oldAddress;
	private Address newAddress;
	private String returnCode;
	

	public Address getOldAddress() {
		return oldAddress;
	}

	public void setOldAddress(Address oldAddress) {
		this.oldAddress = oldAddress;
	}

	public Address getNewAddress() {
		return newAddress;
	}

	public void setNewAddress(Address newAddress) {
		this.newAddress = newAddress;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	@Override
	public String toString() {
		return oldAddress + "," + newAddress + "," + returnCode;
	}

}
