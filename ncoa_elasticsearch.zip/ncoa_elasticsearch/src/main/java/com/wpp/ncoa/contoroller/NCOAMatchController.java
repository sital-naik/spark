package com.wpp.ncoa.contoroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wpp.ncoa.entity.Address;
import com.wpp.ncoa.entity.OutputEntity;
import com.wpp.ncoa.service.NCOAMatchService;

@RestController
public class NCOAMatchController {
	
	@Autowired
	private NCOAMatchService ncoaMatchService;

	@PostMapping
	public List<OutputEntity> ncoa(List<Address> list) throws Exception {
		return ncoaMatchService.processNCOA(list);
	}

}
