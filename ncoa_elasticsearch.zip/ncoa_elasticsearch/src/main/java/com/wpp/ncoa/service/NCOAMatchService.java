package com.wpp.ncoa.service;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wpp.ncoa.dao.ELasticSearchDAO;
import com.wpp.ncoa.entity.Address;
import com.wpp.ncoa.entity.OutputEntity;

@Service
public class NCOAMatchService {

	private static final Logger logger = LoggerFactory.getLogger(NCOAMatchService.class);

	@Value("${ncoa.batch.threadcount}")
	private int threadcount;

	private ELasticSearchDAO elasticDAO;

	@Autowired
	private ELasticSearchDAO eLasticSearchDAO;

	public List<OutputEntity> processNCOA(List<Address> list) throws Exception {
		int length = list.size() - 1;
		int startIndex = 0, endIndex, sublistSize = length / threadcount;

		CompletableFuture<List<OutputEntity>> searchCOA;

		@SuppressWarnings("unchecked")
		CompletableFuture<List<OutputEntity>>[] futureList = new CompletableFuture[threadcount];
		List<OutputEntity> resultList = new LinkedList<>();
		for (int i = 0; i < threadcount; i++) {
			endIndex = startIndex + sublistSize;
			if (endIndex > length) {
				endIndex = length;
			}
			searchCOA = elasticDAO.searchCOA(list.subList(startIndex, endIndex));
			startIndex = endIndex + 1;
		}
		
		CompletableFuture.allOf(futureList).join();

		for (int i = 0; i < threadcount; i++) {
			resultList.addAll(futureList[i].get());
		}

		return resultList;
	}

}
